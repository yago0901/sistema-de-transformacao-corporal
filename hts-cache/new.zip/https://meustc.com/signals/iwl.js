<!doctype html>
<html lang="en-US">
<head>
	
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5, viewport-fit=cover">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<title>Page not found &#8211; STC</title>
<meta name='robots' content='max-image-preview:large' />
<script type='application/javascript'>console.log('PixelYourSite Free version 9.4.7.1');</script>
<link rel="alternate" type="application/rss+xml" title="STC &raquo; Feed" href="https://meustc.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="STC &raquo; Comments Feed" href="https://meustc.com/comments/feed/" />
<link rel='stylesheet' id='blocksy-dynamic-global-css' href='https://meustc.com/wp-content/uploads/blocksy/css/global.css?ver=64363' media='all' />
<link rel='stylesheet' id='wp-block-library-css' href='https://meustc.com/wp-includes/css/dist/block-library/style.min.css?ver=6.4.3' media='all' />
<link rel='stylesheet' id='activecampaign-form-block-css' href='https://meustc.com/wp-content/plugins/activecampaign-subscription-forms/activecampaign-form-block/build/style-index.css?ver=1700673464' media='all' />
<style id='global-styles-inline-css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--color--palette-color-1: var(--theme-palette-color-1, #2872fa);--wp--preset--color--palette-color-2: var(--theme-palette-color-2, #1559ed);--wp--preset--color--palette-color-3: var(--theme-palette-color-3, #3A4F66);--wp--preset--color--palette-color-4: var(--theme-palette-color-4, #192a3d);--wp--preset--color--palette-color-5: var(--theme-palette-color-5, #e1e8ed);--wp--preset--color--palette-color-6: var(--theme-palette-color-6, #f2f5f7);--wp--preset--color--palette-color-7: var(--theme-palette-color-7, #FAFBFC);--wp--preset--color--palette-color-8: var(--theme-palette-color-8, #ffffff);--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--gradient--juicy-peach: linear-gradient(to right, #ffecd2 0%, #fcb69f 100%);--wp--preset--gradient--young-passion: linear-gradient(to right, #ff8177 0%, #ff867a 0%, #ff8c7f 21%, #f99185 52%, #cf556c 78%, #b12a5b 100%);--wp--preset--gradient--true-sunset: linear-gradient(to right, #fa709a 0%, #fee140 100%);--wp--preset--gradient--morpheus-den: linear-gradient(to top, #30cfd0 0%, #330867 100%);--wp--preset--gradient--plum-plate: linear-gradient(135deg, #667eea 0%, #764ba2 100%);--wp--preset--gradient--aqua-splash: linear-gradient(15deg, #13547a 0%, #80d0c7 100%);--wp--preset--gradient--love-kiss: linear-gradient(to top, #ff0844 0%, #ffb199 100%);--wp--preset--gradient--new-retrowave: linear-gradient(to top, #3b41c5 0%, #a981bb 49%, #ffc8a9 100%);--wp--preset--gradient--plum-bath: linear-gradient(to top, #cc208e 0%, #6713d2 100%);--wp--preset--gradient--high-flight: linear-gradient(to right, #0acffe 0%, #495aff 100%);--wp--preset--gradient--teen-party: linear-gradient(-225deg, #FF057C 0%, #8D0B93 50%, #321575 100%);--wp--preset--gradient--fabled-sunset: linear-gradient(-225deg, #231557 0%, #44107A 29%, #FF1361 67%, #FFF800 100%);--wp--preset--gradient--arielle-smile: radial-gradient(circle 248px at center, #16d9e3 0%, #30c7ec 47%, #46aef7 100%);--wp--preset--gradient--itmeo-branding: linear-gradient(180deg, #2af598 0%, #009efd 100%);--wp--preset--gradient--deep-blue: linear-gradient(to right, #6a11cb 0%, #2575fc 100%);--wp--preset--gradient--strong-bliss: linear-gradient(to right, #f78ca0 0%, #f9748f 19%, #fd868c 60%, #fe9a8b 100%);--wp--preset--gradient--sweet-period: linear-gradient(to top, #3f51b1 0%, #5a55ae 13%, #7b5fac 25%, #8f6aae 38%, #a86aa4 50%, #cc6b8e 62%, #f18271 75%, #f3a469 87%, #f7c978 100%);--wp--preset--gradient--purple-division: linear-gradient(to top, #7028e4 0%, #e5b2ca 100%);--wp--preset--gradient--cold-evening: linear-gradient(to top, #0c3483 0%, #a2b6df 100%, #6b8cce 100%, #a2b6df 100%);--wp--preset--gradient--mountain-rock: linear-gradient(to right, #868f96 0%, #596164 100%);--wp--preset--gradient--desert-hump: linear-gradient(to top, #c79081 0%, #dfa579 100%);--wp--preset--gradient--ethernal-constance: linear-gradient(to top, #09203f 0%, #537895 100%);--wp--preset--gradient--happy-memories: linear-gradient(-60deg, #ff5858 0%, #f09819 100%);--wp--preset--gradient--grown-early: linear-gradient(to top, #0ba360 0%, #3cba92 100%);--wp--preset--gradient--morning-salad: linear-gradient(-225deg, #B7F8DB 0%, #50A7C2 100%);--wp--preset--gradient--night-call: linear-gradient(-225deg, #AC32E4 0%, #7918F2 48%, #4801FF 100%);--wp--preset--gradient--mind-crawl: linear-gradient(-225deg, #473B7B 0%, #3584A7 51%, #30D2BE 100%);--wp--preset--gradient--angel-care: linear-gradient(-225deg, #FFE29F 0%, #FFA99F 48%, #FF719A 100%);--wp--preset--gradient--juicy-cake: linear-gradient(to top, #e14fad 0%, #f9d423 100%);--wp--preset--gradient--rich-metal: linear-gradient(to right, #d7d2cc 0%, #304352 100%);--wp--preset--gradient--mole-hall: linear-gradient(-20deg, #616161 0%, #9bc5c3 100%);--wp--preset--gradient--cloudy-knoxville: linear-gradient(120deg, #fdfbfb 0%, #ebedee 100%);--wp--preset--gradient--soft-grass: linear-gradient(to top, #c1dfc4 0%, #deecdd 100%);--wp--preset--gradient--saint-petersburg: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);--wp--preset--gradient--everlasting-sky: linear-gradient(135deg, #fdfcfb 0%, #e2d1c3 100%);--wp--preset--gradient--kind-steel: linear-gradient(-20deg, #e9defa 0%, #fbfcdb 100%);--wp--preset--gradient--over-sun: linear-gradient(60deg, #abecd6 0%, #fbed96 100%);--wp--preset--gradient--premium-white: linear-gradient(to top, #d5d4d0 0%, #d5d4d0 1%, #eeeeec 31%, #efeeec 75%, #e9e9e7 100%);--wp--preset--gradient--clean-mirror: linear-gradient(45deg, #93a5cf 0%, #e4efe9 100%);--wp--preset--gradient--wild-apple: linear-gradient(to top, #d299c2 0%, #fef9d7 100%);--wp--preset--gradient--snow-again: linear-gradient(to top, #e6e9f0 0%, #eef1f5 100%);--wp--preset--gradient--confident-cloud: linear-gradient(to top, #dad4ec 0%, #dad4ec 1%, #f3e7e9 100%);--wp--preset--gradient--glass-water: linear-gradient(to top, #dfe9f3 0%, white 100%);--wp--preset--gradient--perfect-white: linear-gradient(-225deg, #E3FDF5 0%, #FFE6FA 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: clamp(22px, 1.375rem + ((1vw - 3.2px) * 0.625), 30px);--wp--preset--font-size--x-large: clamp(30px, 1.875rem + ((1vw - 3.2px) * 1.563), 50px);--wp--preset--font-size--xx-large: clamp(45px, 2.813rem + ((1vw - 3.2px) * 2.734), 80px);--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}body { margin: 0;--wp--style--global--content-size: var(--theme-block-max-width);--wp--style--global--wide-size: var(--theme-block-wide-max-width); }.wp-site-blocks > .alignleft { float: left; margin-right: 2em; }.wp-site-blocks > .alignright { float: right; margin-left: 2em; }.wp-site-blocks > .aligncenter { justify-content: center; margin-left: auto; margin-right: auto; }:where(.wp-site-blocks) > * { margin-block-start: var(--theme-content-spacing); margin-block-end: 0; }:where(.wp-site-blocks) > :first-child:first-child { margin-block-start: 0; }:where(.wp-site-blocks) > :last-child:last-child { margin-block-end: 0; }body { --wp--style--block-gap: var(--theme-content-spacing); }:where(body .is-layout-flow)  > :first-child:first-child{margin-block-start: 0;}:where(body .is-layout-flow)  > :last-child:last-child{margin-block-end: 0;}:where(body .is-layout-flow)  > *{margin-block-start: var(--theme-content-spacing);margin-block-end: 0;}:where(body .is-layout-constrained)  > :first-child:first-child{margin-block-start: 0;}:where(body .is-layout-constrained)  > :last-child:last-child{margin-block-end: 0;}:where(body .is-layout-constrained)  > *{margin-block-start: var(--theme-content-spacing);margin-block-end: 0;}:where(body .is-layout-flex) {gap: var(--theme-content-spacing);}:where(body .is-layout-grid) {gap: var(--theme-content-spacing);}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}body{padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-palette-color-1-color{color: var(--wp--preset--color--palette-color-1) !important;}.has-palette-color-2-color{color: var(--wp--preset--color--palette-color-2) !important;}.has-palette-color-3-color{color: var(--wp--preset--color--palette-color-3) !important;}.has-palette-color-4-color{color: var(--wp--preset--color--palette-color-4) !important;}.has-palette-color-5-color{color: var(--wp--preset--color--palette-color-5) !important;}.has-palette-color-6-color{color: var(--wp--preset--color--palette-color-6) !important;}.has-palette-color-7-color{color: var(--wp--preset--color--palette-color-7) !important;}.has-palette-color-8-color{color: var(--wp--preset--color--palette-color-8) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-palette-color-1-background-color{background-color: var(--wp--preset--color--palette-color-1) !important;}.has-palette-color-2-background-color{background-color: var(--wp--preset--color--palette-color-2) !important;}.has-palette-color-3-background-color{background-color: var(--wp--preset--color--palette-color-3) !important;}.has-palette-color-4-background-color{background-color: var(--wp--preset--color--palette-color-4) !important;}.has-palette-color-5-background-color{background-color: var(--wp--preset--color--palette-color-5) !important;}.has-palette-color-6-background-color{background-color: var(--wp--preset--color--palette-color-6) !important;}.has-palette-color-7-background-color{background-color: var(--wp--preset--color--palette-color-7) !important;}.has-palette-color-8-background-color{background-color: var(--wp--preset--color--palette-color-8) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-palette-color-1-border-color{border-color: var(--wp--preset--color--palette-color-1) !important;}.has-palette-color-2-border-color{border-color: var(--wp--preset--color--palette-color-2) !important;}.has-palette-color-3-border-color{border-color: var(--wp--preset--color--palette-color-3) !important;}.has-palette-color-4-border-color{border-color: var(--wp--preset--color--palette-color-4) !important;}.has-palette-color-5-border-color{border-color: var(--wp--preset--color--palette-color-5) !important;}.has-palette-color-6-border-color{border-color: var(--wp--preset--color--palette-color-6) !important;}.has-palette-color-7-border-color{border-color: var(--wp--preset--color--palette-color-7) !important;}.has-palette-color-8-border-color{border-color: var(--wp--preset--color--palette-color-8) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-juicy-peach-gradient-background{background: var(--wp--preset--gradient--juicy-peach) !important;}.has-young-passion-gradient-background{background: var(--wp--preset--gradient--young-passion) !important;}.has-true-sunset-gradient-background{background: var(--wp--preset--gradient--true-sunset) !important;}.has-morpheus-den-gradient-background{background: var(--wp--preset--gradient--morpheus-den) !important;}.has-plum-plate-gradient-background{background: var(--wp--preset--gradient--plum-plate) !important;}.has-aqua-splash-gradient-background{background: var(--wp--preset--gradient--aqua-splash) !important;}.has-love-kiss-gradient-background{background: var(--wp--preset--gradient--love-kiss) !important;}.has-new-retrowave-gradient-background{background: var(--wp--preset--gradient--new-retrowave) !important;}.has-plum-bath-gradient-background{background: var(--wp--preset--gradient--plum-bath) !important;}.has-high-flight-gradient-background{background: var(--wp--preset--gradient--high-flight) !important;}.has-teen-party-gradient-background{background: var(--wp--preset--gradient--teen-party) !important;}.has-fabled-sunset-gradient-background{background: var(--wp--preset--gradient--fabled-sunset) !important;}.has-arielle-smile-gradient-background{background: var(--wp--preset--gradient--arielle-smile) !important;}.has-itmeo-branding-gradient-background{background: var(--wp--preset--gradient--itmeo-branding) !important;}.has-deep-blue-gradient-background{background: var(--wp--preset--gradient--deep-blue) !important;}.has-strong-bliss-gradient-background{background: var(--wp--preset--gradient--strong-bliss) !important;}.has-sweet-period-gradient-background{background: var(--wp--preset--gradient--sweet-period) !important;}.has-purple-division-gradient-background{background: var(--wp--preset--gradient--purple-division) !important;}.has-cold-evening-gradient-background{background: var(--wp--preset--gradient--cold-evening) !important;}.has-mountain-rock-gradient-background{background: var(--wp--preset--gradient--mountain-rock) !important;}.has-desert-hump-gradient-background{background: var(--wp--preset--gradient--desert-hump) !important;}.has-ethernal-constance-gradient-background{background: var(--wp--preset--gradient--ethernal-constance) !important;}.has-happy-memories-gradient-background{background: var(--wp--preset--gradient--happy-memories) !important;}.has-grown-early-gradient-background{background: var(--wp--preset--gradient--grown-early) !important;}.has-morning-salad-gradient-background{background: var(--wp--preset--gradient--morning-salad) !important;}.has-night-call-gradient-background{background: var(--wp--preset--gradient--night-call) !important;}.has-mind-crawl-gradient-background{background: var(--wp--preset--gradient--mind-crawl) !important;}.has-angel-care-gradient-background{background: var(--wp--preset--gradient--angel-care) !important;}.has-juicy-cake-gradient-background{background: var(--wp--preset--gradient--juicy-cake) !important;}.has-rich-metal-gradient-background{background: var(--wp--preset--gradient--rich-metal) !important;}.has-mole-hall-gradient-background{background: var(--wp--preset--gradient--mole-hall) !important;}.has-cloudy-knoxville-gradient-background{background: var(--wp--preset--gradient--cloudy-knoxville) !important;}.has-soft-grass-gradient-background{background: var(--wp--preset--gradient--soft-grass) !important;}.has-saint-petersburg-gradient-background{background: var(--wp--preset--gradient--saint-petersburg) !important;}.has-everlasting-sky-gradient-background{background: var(--wp--preset--gradient--everlasting-sky) !important;}.has-kind-steel-gradient-background{background: var(--wp--preset--gradient--kind-steel) !important;}.has-over-sun-gradient-background{background: var(--wp--preset--gradient--over-sun) !important;}.has-premium-white-gradient-background{background: var(--wp--preset--gradient--premium-white) !important;}.has-clean-mirror-gradient-background{background: var(--wp--preset--gradient--clean-mirror) !important;}.has-wild-apple-gradient-background{background: var(--wp--preset--gradient--wild-apple) !important;}.has-snow-again-gradient-background{background: var(--wp--preset--gradient--snow-again) !important;}.has-confident-cloud-gradient-background{background: var(--wp--preset--gradient--confident-cloud) !important;}.has-glass-water-gradient-background{background: var(--wp--preset--gradient--glass-water) !important;}.has-perfect-white-gradient-background{background: var(--wp--preset--gradient--perfect-white) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}.has-xx-large-font-size{font-size: var(--wp--preset--font-size--xx-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
.wp-block-pullquote{font-size: clamp(0.984em, 0.984rem + ((1vw - 0.2em) * 0.645), 1.5em);line-height: 1.6;}
</style>
<link rel='stylesheet' id='elementor-icons-css' href='https://meustc.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.27.0' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://meustc.com/wp-content/plugins/elementor/assets/css/frontend-lite.min.css?ver=3.19.2' media='all' />
<link rel='stylesheet' id='swiper-css' href='https://meustc.com/wp-content/plugins/elementor/assets/lib/swiper/v8/css/swiper.min.css?ver=8.4.5' media='all' />
<link rel='stylesheet' id='elementor-post-10-css' href='https://meustc.com/wp-content/uploads/elementor/css/post-10.css?ver=1707371390' media='all' />
<link rel='stylesheet' id='elementor-pro-css' href='https://meustc.com/wp-content/plugins/elementor-pro/assets/css/frontend-lite.min.css?ver=3.19.2' media='all' />
<link rel='stylesheet' id='ct-main-styles-css' href='https://meustc.com/wp-content/themes/blocksy/static/bundle/main.min.css?ver=2.0.3' media='all' />
<link rel='stylesheet' id='ct-page-title-styles-css' href='https://meustc.com/wp-content/themes/blocksy/static/bundle/page-title.min.css?ver=2.0.3' media='all' />
<link rel='stylesheet' id='ct-elementor-styles-css' href='https://meustc.com/wp-content/themes/blocksy/static/bundle/elementor-frontend.min.css?ver=2.0.3' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Inter%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=swap&#038;ver=6.4.3' media='all' />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin><script src="https://meustc.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://meustc.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script src="https://meustc.com/wp-content/plugins/pixelyoursite/dist/scripts/jquery.bind-first-0.2.3.min.js?ver=6.4.3" id="jquery-bind-first-js"></script>
<script src="https://meustc.com/wp-content/plugins/pixelyoursite/dist/scripts/js.cookie-2.1.3.min.js?ver=2.1.3" id="js-cookie-pys-js"></script>
<script id="pys-js-extra">
var pysOptions = {"staticEvents":{"facebook":{"init_event":[{"delay":0,"type":"static","name":"PageView","pixelIds":["1185330418574865"],"eventID":"d25a9384-2c3d-4ee2-bfdb-0d572a6ee6e1","params":{"post_type":false,"plugin":"PixelYourSite","user_role":"guest","event_url":"meustc.com\/signals\/iwl.js"},"e_id":"init_event","ids":[],"hasTimeWindow":false,"timeWindow":0,"woo_order":"","edd_order":""}]}},"dynamicEvents":{"automatic_event_form":{"facebook":{"delay":0,"type":"dyn","name":"Form","pixelIds":["1185330418574865"],"eventID":"c89ffe6a-b63d-454b-9bd2-07a5f066f69f","params":{"post_type":false,"plugin":"PixelYourSite","user_role":"guest","event_url":"meustc.com\/signals\/iwl.js"},"e_id":"automatic_event_form","ids":[],"hasTimeWindow":false,"timeWindow":0,"woo_order":"","edd_order":""}},"automatic_event_download":{"facebook":{"delay":0,"type":"dyn","name":"Download","extensions":["","doc","exe","js","pdf","ppt","tgz","zip","xls"],"pixelIds":["1185330418574865"],"eventID":"92830f2e-139f-4ea2-9cc8-7f2cadfd542d","params":{"post_type":false,"plugin":"PixelYourSite","user_role":"guest","event_url":"meustc.com\/signals\/iwl.js"},"e_id":"automatic_event_download","ids":[],"hasTimeWindow":false,"timeWindow":0,"woo_order":"","edd_order":""}},"automatic_event_comment":{"facebook":{"delay":0,"type":"dyn","name":"Comment","pixelIds":["1185330418574865"],"eventID":"b564360d-0cba-446a-b102-5305387b70cd","params":{"post_type":false,"plugin":"PixelYourSite","user_role":"guest","event_url":"meustc.com\/signals\/iwl.js"},"e_id":"automatic_event_comment","ids":[],"hasTimeWindow":false,"timeWindow":0,"woo_order":"","edd_order":""}},"automatic_event_scroll":{"facebook":{"delay":0,"type":"dyn","name":"PageScroll","scroll_percent":30,"pixelIds":["1185330418574865"],"eventID":"3edd75d1-4e1c-41fa-8a42-ddaf32225899","params":{"post_type":false,"plugin":"PixelYourSite","user_role":"guest","event_url":"meustc.com\/signals\/iwl.js"},"e_id":"automatic_event_scroll","ids":[],"hasTimeWindow":false,"timeWindow":0,"woo_order":"","edd_order":""}},"automatic_event_time_on_page":{"facebook":{"delay":0,"type":"dyn","name":"TimeOnPage","time_on_page":30,"pixelIds":["1185330418574865"],"eventID":"d274cfaf-0205-4745-b195-8b197e439b3f","params":{"post_type":false,"plugin":"PixelYourSite","user_role":"guest","event_url":"meustc.com\/signals\/iwl.js"},"e_id":"automatic_event_time_on_page","ids":[],"hasTimeWindow":false,"timeWindow":0,"woo_order":"","edd_order":""}}},"triggerEvents":[],"triggerEventTypes":[],"facebook":{"pixelIds":["1185330418574865"],"advancedMatching":{"external_id":"baedbbbfcbdfbddcbededafead"},"advancedMatchingEnabled":true,"removeMetadata":false,"contentParams":[],"commentEventEnabled":true,"wooVariableAsSimple":false,"downloadEnabled":true,"formEventEnabled":true,"serverApiEnabled":true,"wooCRSendFromServer":false,"send_external_id":null},"debug":"","siteUrl":"https:\/\/meustc.com","ajaxUrl":"https:\/\/meustc.com\/wp-admin\/admin-ajax.php","ajax_event":"d61d644829","enable_remove_download_url_param":"1","cookie_duration":"7","last_visit_duration":"60","enable_success_send_form":"","ajaxForServerEvent":"1","send_external_id":"1","external_id_expire":"180","gdpr":{"ajax_enabled":false,"all_disabled_by_api":false,"facebook_disabled_by_api":false,"analytics_disabled_by_api":false,"google_ads_disabled_by_api":false,"pinterest_disabled_by_api":false,"bing_disabled_by_api":false,"externalID_disabled_by_api":false,"facebook_prior_consent_enabled":true,"analytics_prior_consent_enabled":true,"google_ads_prior_consent_enabled":null,"pinterest_prior_consent_enabled":true,"bing_prior_consent_enabled":true,"cookiebot_integration_enabled":false,"cookiebot_facebook_consent_category":"marketing","cookiebot_analytics_consent_category":"statistics","cookiebot_tiktok_consent_category":"marketing","cookiebot_google_ads_consent_category":null,"cookiebot_pinterest_consent_category":"marketing","cookiebot_bing_consent_category":"marketing","consent_magic_integration_enabled":false,"real_cookie_banner_integration_enabled":false,"cookie_notice_integration_enabled":false,"cookie_law_info_integration_enabled":false},"cookie":{"disabled_all_cookie":false,"disabled_advanced_form_data_cookie":false,"disabled_landing_page_cookie":false,"disabled_first_visit_cookie":false,"disabled_trafficsource_cookie":false,"disabled_utmTerms_cookie":false,"disabled_utmId_cookie":false},"woo":{"enabled":false},"edd":{"enabled":false}};
</script>
<script src="https://meustc.com/wp-content/plugins/pixelyoursite/dist/scripts/public.js?ver=9.4.7.1" id="pys-js"></script>
<link rel="https://api.w.org/" href="https://meustc.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://meustc.com/xmlrpc.php?rsd" />
<noscript><link rel='stylesheet' href='https://meustc.com/wp-content/themes/blocksy/static/bundle/no-scripts.min.css' type='text/css'></noscript>
<meta name="generator" content="Elementor 3.19.2; features: e_optimized_assets_loading, e_optimized_css_loading, additional_custom_breakpoints, block_editor_assets_optimize, e_image_loading_optimization; settings: css_print_method-external, google_font-enabled, font_display-swap">
<style>
	.pink-background {
    background-color: #ffccd1;
    padding-right: 10px;
    padding-left: 10px;
	}
	
	.white-background {
    background-color: #FAFBFC;
    padding-right: 10px;
    padding-left: 10px;
	}
	
	.blur-container {
    backdrop-filter: blur(5px);
	}

	.price-red {
    font-size: 12px;
    font-weight: 600;
    color: #C41717;
	}
</style>
<link rel="icon" href="https://meustc.com/wp-content/uploads/2023/10/cropped-STC-Icon-32x32.png" sizes="32x32" />
<link rel="icon" href="https://meustc.com/wp-content/uploads/2023/10/cropped-STC-Icon-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://meustc.com/wp-content/uploads/2023/10/cropped-STC-Icon-180x180.png" />
<meta name="msapplication-TileImage" content="https://meustc.com/wp-content/uploads/2023/10/cropped-STC-Icon-270x270.png" />
	</head>


<body class="error404 wp-embed-responsive elementor-default elementor-kit-10 ct-elementor-default-template" data-link="type-2" data-prefix="" data-header="type-1" data-footer="type-1" >

<a class="skip-link show-on-focus" href="#main">
	Skip to content</a>

<div class="ct-drawer-canvas" data-location="start" >
		<div id="search-modal" class="ct-panel" data-behaviour="modal">
			<div class="ct-panel-actions">
				<button class="ct-toggle-close" data-type="type-1" aria-label="Close search modal">
					<svg class="ct-icon" width="12" height="12" viewBox="0 0 15 15"><path d="M1 15a1 1 0 01-.71-.29 1 1 0 010-1.41l5.8-5.8-5.8-5.8A1 1 0 011.7.29l5.8 5.8 5.8-5.8a1 1 0 011.41 1.41l-5.8 5.8 5.8 5.8a1 1 0 01-1.41 1.41l-5.8-5.8-5.8 5.8A1 1 0 011 15z"/></svg>				</button>
			</div>

			<div class="ct-panel-content">
				

<form role="search" method="get" class="ct-search-form"  action="https://meustc.com/" aria-haspopup="listbox" data-live-results="thumbs">

	<input type="search" class="modal-field" placeholder="Search" value="" name="s" autocomplete="off" title="Search for..." aria-label="Search for...">

	<div class="ct-search-form-controls">
		
		<button type="submit" class="wp-element-button" data-button="icon" aria-label="Search button" >
			<svg class="ct-icon ct-search-button-content" aria-hidden="true" width="15" height="15" viewBox="0 0 15 15"><path d="M14.8,13.7L12,11c0.9-1.2,1.5-2.6,1.5-4.2c0-3.7-3-6.8-6.8-6.8S0,3,0,6.8s3,6.8,6.8,6.8c1.6,0,3.1-0.6,4.2-1.5l2.8,2.8c0.1,0.1,0.3,0.2,0.5,0.2s0.4-0.1,0.5-0.2C15.1,14.5,15.1,14,14.8,13.7z M1.5,6.8c0-2.9,2.4-5.2,5.2-5.2S12,3.9,12,6.8S9.6,12,6.8,12S1.5,9.6,1.5,6.8z"/></svg>
			<span class="ct-ajax-loader">
				<svg viewBox="0 0 24 24">
					<circle cx="12" cy="12" r="10" opacity="0.2" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="2"/>

					<path d="m12,2c5.52,0,10,4.48,10,10" fill="none" stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2">
						<animateTransform
							attributeName="transform"
							attributeType="XML"
							type="rotate"
							dur="0.6s"
							from="0 12 12"
							to="360 12 12"
							repeatCount="indefinite"
						/>
					</path>
				</svg>
			</span>
		</button>

		
					<input type="hidden" name="ct_post_type" value="post:page">
		
		
			</div>

			<div class="screen-reader-text" aria-live="polite" role="status">
			No results		</div>
	
</form>


			</div>
		</div>

		<div id="offcanvas" class="ct-panel ct-header" data-behaviour="right-side" ><div class="ct-panel-inner">
		<div class="ct-panel-actions">
			
			<button class="ct-toggle-close" data-type="type-1" aria-label="Close drawer">
				<svg class="ct-icon" width="12" height="12" viewBox="0 0 15 15"><path d="M1 15a1 1 0 01-.71-.29 1 1 0 010-1.41l5.8-5.8-5.8-5.8A1 1 0 011.7.29l5.8 5.8 5.8-5.8a1 1 0 011.41 1.41l-5.8 5.8 5.8 5.8a1 1 0 01-1.41 1.41l-5.8-5.8-5.8 5.8A1 1 0 011 15z"/></svg>
			</button>
		</div>
		<div class="ct-panel-content" data-device="desktop" ><div class="ct-panel-content-inner"></div></div><div class="ct-panel-content" data-device="mobile" ><div class="ct-panel-content-inner">
<nav
	class="mobile-menu has-submenu"
	data-id="mobile-menu" data-interaction="click" data-toggle-type="type-1" 	aria-label="Off Canvas Menu">
	<ul><li class="page_item page-item-515"><a href="https://meustc.com/aguardando-pagamento-pix/" class="ct-menu-link">Aguardando pagamento PIX</a></li><li class="page_item page-item-100"><a href="https://meustc.com/analise-corporal/" class="ct-menu-link">Analise Corporal</a></li><li class="page_item page-item-405"><a href="https://meustc.com/analise-corporal-desafio-parabens/" class="ct-menu-link">Analise Corporal &#8211; Desafio &#8211; Parabéns</a></li><li class="page_item page-item-151"><a href="https://meustc.com/analise-corporal-obrigado/" class="ct-menu-link">Analise Corporal &#8211; Obrigado</a></li><li class="page_item page-item-421"><a href="https://meustc.com/analise-corporal-obrigado-eu/" class="ct-menu-link">Analise Corporal &#8211; Obrigado EU</a></li><li class="page_item page-item-419"><a href="https://meustc.com/analise-corporal-obrigado-eua/" class="ct-menu-link">Analise Corporal &#8211; Obrigado EUA</a></li><li class="page_item page-item-417"><a href="https://meustc.com/analise-corporal-eu/" class="ct-menu-link">Analise Corporal EU</a></li><li class="page_item page-item-415"><a href="https://meustc.com/analise-corporal-eua/" class="ct-menu-link">Analise Corporal EUA</a></li><li class="page_item page-item-133"><a href="https://meustc.com/coach-stc/" class="ct-menu-link">Coach STC</a></li><li class="page_item page-item-225"><a href="https://meustc.com/coach-stc-agradecimento/" class="ct-menu-link">Coach STC Agradecimento</a></li><li class="page_item page-item-210"><a href="https://meustc.com/coaches-obrigada/" class="ct-menu-link">Coaches &#8211; Obrigada</a></li><li class="page_item page-item-232"><a href="https://meustc.com/ebook/" class="ct-menu-link">Ebook Receitas Fit Coaches</a></li><li class="page_item page-item-238"><a href="https://meustc.com/ebook-stc-obrigado/" class="ct-menu-link">Ebook STC Obrigado</a></li><li class="page_item page-item-138"><a href="https://meustc.com/o-stc-funciona-mesmo/" class="ct-menu-link">O STC funciona mesmo?</a></li><li class="page_item page-item-11"><a href="https://meustc.com/pagina-principal/" class="ct-menu-link">Página principal</a></li><li class="page_item page-item-573"><a href="https://meustc.com/" class="ct-menu-link">Página principal &#8211; Novo Valor</a></li><li class="page_item page-item-520"><a href="https://meustc.com/promocao-desafio-br/" class="ct-menu-link">Página Promocional</a></li><li class="page_item page-item-272"><a href="https://meustc.com/pagina-promocional/" class="ct-menu-link">Página Promocional</a></li><li class="page_item page-item-539"><a href="https://meustc.com/pagina-promocional-natal/" class="ct-menu-link">Página Promocional &#8211; Natal</a></li><li class="page_item page-item-287"><a href="https://meustc.com/obrigada-pesquisa/" class="ct-menu-link">Pesquisa Obrigado</a></li><li class="page_item page-item-459"><a href="https://meustc.com/promocao-exclusiva-2/" class="ct-menu-link">Promoção Exclusiva</a></li><li class="page_item page-item-470"><a href="https://meustc.com/promocao-exclusiva-obrigado/" class="ct-menu-link">Promoção Exclusiva &#8211; Obrigado</a></li><li class="page_item page-item-178"><a href="https://meustc.com/sera-que-o-stc-e-pra-mim/" class="ct-menu-link">Será que o STC é pra mim?</a></li><li class="page_item page-item-169"><a href="https://meustc.com/oficial-video/" class="ct-menu-link">STC</a></li><li class="page_item page-item-334 page_item_has_children menu-item-has-children"><span class="ct-sub-menu-parent"><a href="https://meustc.com/treinamento-afiliados-principal/" class="ct-menu-link">Treinamento Afiliados &#8211; Principal</a><button class="ct-toggle-dropdown-mobile" aria-label="Expand dropdown menu" aria-haspopup="true" aria-expanded="false" ><svg class="ct-icon toggle-icon-1" width="15" height="15" viewBox="0 0 15 15"><path d="M3.9,5.1l3.6,3.6l3.6-3.6l1.4,0.7l-5,5l-5-5L3.9,5.1z"/></svg></button></span><ul class='sub-menu' role='menu'><li class="page_item page-item-321"><a href="https://meustc.com/treinamento-afiliados-principal/treinamento-afiliados-estrutura-propria/" class="ct-menu-link">Treinamento Afiliados &#8211; Estrutura Própria</a></li><li class="page_item page-item-367"><a href="https://meustc.com/treinamento-afiliados-principal/treinamento-afiliados-primeira-venda-no-instagram/" class="ct-menu-link">Treinamento Afiliados &#8211; Primeira venda no Instagram</a></li><li class="page_item page-item-359"><a href="https://meustc.com/treinamento-afiliados-principal/treinamento-afiliados-primeiros-passos/" class="ct-menu-link">Treinamento Afiliados &#8211; Primeiros Passos</a></li></ul></li><li class="page_item page-item-189"><a href="https://meustc.com/truque-matador-para-acabar-com-vontade-de-comer-doces/" class="ct-menu-link">Truque matador para acabar com vontade de comer doces!</a></li></ul></nav>

</div></div></div></div></div>
<div id="main-container">
	<header id="header" class="ct-header" data-id="type-1" itemscope="" itemtype="https://schema.org/WPHeader" ><div data-device="desktop" ><div data-row="middle" data-column-set="2" ><div class="ct-container" ><div data-column="start" data-placements="1" ><div data-items="primary" >
<div	class="site-branding"
	data-id="logo" 		itemscope="itemscope" itemtype="https://schema.org/Organization" >

	
			<div class="site-title-container">
							<span class="site-title " itemprop="name" >
					<a href="https://meustc.com/" rel="home" itemprop="url" >
						STC					</a>
				</span>
			
					</div>
	  </div>

</div></div><div data-column="end" data-placements="1" ><div data-items="primary" >
<nav
	id="header-menu-1"
	class="header-menu-1"
	data-id="menu" data-interaction="hover" 	data-menu="type-1"
	data-dropdown="type-1:simple"		data-responsive="no"	itemscope="" itemtype="https://schema.org/SiteNavigationElement" 	aria-label="Header Menu">

	<ul class="menu"><li class="page_item page-item-515"><a href="https://meustc.com/aguardando-pagamento-pix/" class="ct-menu-link">Aguardando pagamento PIX</a></li><li class="page_item page-item-100"><a href="https://meustc.com/analise-corporal/" class="ct-menu-link">Analise Corporal</a></li><li class="page_item page-item-405"><a href="https://meustc.com/analise-corporal-desafio-parabens/" class="ct-menu-link">Analise Corporal &#8211; Desafio &#8211; Parabéns</a></li><li class="page_item page-item-151"><a href="https://meustc.com/analise-corporal-obrigado/" class="ct-menu-link">Analise Corporal &#8211; Obrigado</a></li><li class="page_item page-item-421"><a href="https://meustc.com/analise-corporal-obrigado-eu/" class="ct-menu-link">Analise Corporal &#8211; Obrigado EU</a></li><li class="page_item page-item-419"><a href="https://meustc.com/analise-corporal-obrigado-eua/" class="ct-menu-link">Analise Corporal &#8211; Obrigado EUA</a></li><li class="page_item page-item-417"><a href="https://meustc.com/analise-corporal-eu/" class="ct-menu-link">Analise Corporal EU</a></li><li class="page_item page-item-415"><a href="https://meustc.com/analise-corporal-eua/" class="ct-menu-link">Analise Corporal EUA</a></li><li class="page_item page-item-133"><a href="https://meustc.com/coach-stc/" class="ct-menu-link">Coach STC</a></li><li class="page_item page-item-225"><a href="https://meustc.com/coach-stc-agradecimento/" class="ct-menu-link">Coach STC Agradecimento</a></li><li class="page_item page-item-210"><a href="https://meustc.com/coaches-obrigada/" class="ct-menu-link">Coaches &#8211; Obrigada</a></li><li class="page_item page-item-232"><a href="https://meustc.com/ebook/" class="ct-menu-link">Ebook Receitas Fit Coaches</a></li><li class="page_item page-item-238"><a href="https://meustc.com/ebook-stc-obrigado/" class="ct-menu-link">Ebook STC Obrigado</a></li><li class="page_item page-item-138"><a href="https://meustc.com/o-stc-funciona-mesmo/" class="ct-menu-link">O STC funciona mesmo?</a></li><li class="page_item page-item-11"><a href="https://meustc.com/pagina-principal/" class="ct-menu-link">Página principal</a></li><li class="page_item page-item-573"><a href="https://meustc.com/" class="ct-menu-link">Página principal &#8211; Novo Valor</a></li><li class="page_item page-item-520"><a href="https://meustc.com/promocao-desafio-br/" class="ct-menu-link">Página Promocional</a></li><li class="page_item page-item-272"><a href="https://meustc.com/pagina-promocional/" class="ct-menu-link">Página Promocional</a></li><li class="page_item page-item-539"><a href="https://meustc.com/pagina-promocional-natal/" class="ct-menu-link">Página Promocional &#8211; Natal</a></li><li class="page_item page-item-287"><a href="https://meustc.com/obrigada-pesquisa/" class="ct-menu-link">Pesquisa Obrigado</a></li><li class="page_item page-item-459"><a href="https://meustc.com/promocao-exclusiva-2/" class="ct-menu-link">Promoção Exclusiva</a></li><li class="page_item page-item-470"><a href="https://meustc.com/promocao-exclusiva-obrigado/" class="ct-menu-link">Promoção Exclusiva &#8211; Obrigado</a></li><li class="page_item page-item-178"><a href="https://meustc.com/sera-que-o-stc-e-pra-mim/" class="ct-menu-link">Será que o STC é pra mim?</a></li><li class="page_item page-item-169"><a href="https://meustc.com/oficial-video/" class="ct-menu-link">STC</a></li><li class="page_item page-item-334 page_item_has_children menu-item-has-children animated-submenu"><a href="https://meustc.com/treinamento-afiliados-principal/" class="ct-menu-link">Treinamento Afiliados &#8211; Principal<span class="ct-toggle-dropdown-desktop" role="button" ><svg class="ct-icon" width="8" height="8" viewBox="0 0 15 15"><path d="M2.1,3.2l5.4,5.4l5.4-5.4L15,4.3l-7.5,7.5L0,4.3L2.1,3.2z"/></svg></span></a><button class="ct-toggle-dropdown-desktop-ghost" aria-label="Expand dropdown menu" aria-haspopup="true" aria-expanded="false" role="menuitem" ></button><ul class='sub-menu' role='menu'><li class="page_item page-item-321"><a href="https://meustc.com/treinamento-afiliados-principal/treinamento-afiliados-estrutura-propria/" class="ct-menu-link">Treinamento Afiliados &#8211; Estrutura Própria</a></li><li class="page_item page-item-367"><a href="https://meustc.com/treinamento-afiliados-principal/treinamento-afiliados-primeira-venda-no-instagram/" class="ct-menu-link">Treinamento Afiliados &#8211; Primeira venda no Instagram</a></li><li class="page_item page-item-359"><a href="https://meustc.com/treinamento-afiliados-principal/treinamento-afiliados-primeiros-passos/" class="ct-menu-link">Treinamento Afiliados &#8211; Primeiros Passos</a></li></ul></li><li class="page_item page-item-189"><a href="https://meustc.com/truque-matador-para-acabar-com-vontade-de-comer-doces/" class="ct-menu-link">Truque matador para acabar com vontade de comer doces!</a></li></ul></nav>


<button
	data-toggle-panel="#search-modal"
	class="ct-header-search ct-toggle "
	aria-label="Search"
	data-label="left"
	data-id="search" >

	<span class="ct-label ct-hidden-sm ct-hidden-md ct-hidden-lg">Search</span>

	<svg class="ct-icon" aria-hidden="true" width="15" height="15" viewBox="0 0 15 15"><path d="M14.8,13.7L12,11c0.9-1.2,1.5-2.6,1.5-4.2c0-3.7-3-6.8-6.8-6.8S0,3,0,6.8s3,6.8,6.8,6.8c1.6,0,3.1-0.6,4.2-1.5l2.8,2.8c0.1,0.1,0.3,0.2,0.5,0.2s0.4-0.1,0.5-0.2C15.1,14.5,15.1,14,14.8,13.7z M1.5,6.8c0-2.9,2.4-5.2,5.2-5.2S12,3.9,12,6.8S9.6,12,6.8,12S1.5,9.6,1.5,6.8z"/></svg></button>
</div></div></div></div></div><div data-device="mobile" ><div data-row="middle" data-column-set="2" ><div class="ct-container" ><div data-column="start" data-placements="1" ><div data-items="primary" >
<div	class="site-branding"
	data-id="logo" 		>

	
			<div class="site-title-container">
							<span class="site-title " >
					<a href="https://meustc.com/" rel="home" >
						STC					</a>
				</span>
			
					</div>
	  </div>

</div></div><div data-column="end" data-placements="1" ><div data-items="primary" >
<button
	data-toggle-panel="#offcanvas"
	class="ct-header-trigger ct-toggle "
	data-design="simple"
	data-label="right"
	aria-label="Menu"
	data-id="trigger" >

	<span class="ct-label ct-hidden-sm ct-hidden-md ct-hidden-lg">Menu</span>

	<svg
		class="ct-icon"
		width="18" height="14" viewBox="0 0 18 14"
		aria-hidden="true"
		data-type="type-1">

		<rect y="0.00" width="18" height="1.7" rx="1"/>
		<rect y="6.15" width="18" height="1.7" rx="1"/>
		<rect y="12.3" width="18" height="1.7" rx="1"/>
	</svg>
</button>
</div></div></div></div></div></header>
	<main id="main" class="site-main hfeed" >

		<div class="ct-container" data-vertical-spacing="top:bottom">
	<section class="ct-no-results">

		<section class="hero-section" data-type="type-1">
			<header class="entry-header">
				<h1 class="page-title" itemprop="headline">
					Oops! That page can&rsquo;t be found.	
				</h1>

				<div class="page-description">
					It looks like nothing was found at this location. Maybe try to search for something else?				</div>
			</header>
		</section>

		<div class="entry-content">
			

<form role="search" method="get" class="ct-search-form" data-form-controls="inside" data-taxonomy-filter="false" data-submit-button="icon"  action="https://meustc.com/" aria-haspopup="listbox" data-live-results="thumbs">

	<input type="search"  placeholder="Search" value="" name="s" autocomplete="off" title="Search for..." aria-label="Search for...">

	<div class="ct-search-form-controls">
		
		<button type="submit" class="wp-element-button" data-button="inside:icon" aria-label="Search button" >
			<svg class="ct-icon ct-search-button-content" aria-hidden="true" width="15" height="15" viewBox="0 0 15 15"><path d="M14.8,13.7L12,11c0.9-1.2,1.5-2.6,1.5-4.2c0-3.7-3-6.8-6.8-6.8S0,3,0,6.8s3,6.8,6.8,6.8c1.6,0,3.1-0.6,4.2-1.5l2.8,2.8c0.1,0.1,0.3,0.2,0.5,0.2s0.4-0.1,0.5-0.2C15.1,14.5,15.1,14,14.8,13.7z M1.5,6.8c0-2.9,2.4-5.2,5.2-5.2S12,3.9,12,6.8S9.6,12,6.8,12S1.5,9.6,1.5,6.8z"/></svg>
			<span class="ct-ajax-loader">
				<svg viewBox="0 0 24 24">
					<circle cx="12" cy="12" r="10" opacity="0.2" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="2"/>

					<path d="m12,2c5.52,0,10,4.48,10,10" fill="none" stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2">
						<animateTransform
							attributeName="transform"
							attributeType="XML"
							type="rotate"
							dur="0.6s"
							from="0 12 12"
							to="360 12 12"
							repeatCount="indefinite"
						/>
					</path>
				</svg>
			</span>
		</button>

		
		
		
			</div>

			<div class="screen-reader-text" aria-live="polite" role="status">
			No results		</div>
	
</form>


		</div>

	</section>
</div>	</main>

	<footer id="footer" class="ct-footer" data-id="type-1" itemscope="" itemtype="https://schema.org/WPFooter" ><div data-row="bottom" ><div class="ct-container" data-columns-divider="md:sm" ><div data-column="copyright" >
<div
	class="ct-footer-copyright"
	data-id="copyright" >

	Copyright &copy; 2024 - WordPress Theme by <a href="https://creativethemes.com" >CreativeThemes</a></div>
</div></div></div></footer></div>

<noscript><img height="1" width="1" style="display: none;" src="https://www.facebook.com/tr?id=1185330418574865&ev=PageView&noscript=1&cd%5Bpost_type%5D&cd%5Bplugin%5D=PixelYourSite&cd%5Buser_role%5D=guest&cd%5Bevent_url%5D=meustc.com%2Fsignals%2Fiwl.js" alt=""></noscript>
<script id="site_tracking-js-extra">
var php_data = {"ac_settings":{"tracking_actid":null,"site_tracking_default":1},"user_email":""};
</script>
<script src="https://meustc.com/wp-content/plugins/activecampaign-subscription-forms/site_tracking.js?ver=6.4.3" id="site_tracking-js"></script>
<script id="ct-scripts-js-extra">
var ct_localizations = {"ajax_url":"https:\/\/meustc.com\/wp-admin\/admin-ajax.php","nonce":"ee6c42aded","rest_api_nonce":"ae12c18419","public_url":"https:\/\/meustc.com\/wp-content\/themes\/blocksy\/static\/bundle\/","rest_url":"https:\/\/meustc.com\/wp-json\/","search_url":"https:\/\/meustc.com\/search\/QUERY_STRING\/","show_more_text":"Show more","more_text":"More","search_live_results":"Search results","search_live_no_result":"No results","search_live_one_result":"You got %s result. Please press Tab to select it.","search_live_many_results":"You got %s results. Please press Tab to select one.","expand_submenu":"Expand dropdown menu","collapse_submenu":"Collapse dropdown menu","dynamic_js_chunks":[{"id":"blocksy_sticky_header","selector":"header [data-sticky]","url":"https:\/\/meustc.com\/wp-content\/plugins\/blocksy-companion\/static\/bundle\/sticky.js?ver=2.0.3"}],"dynamic_styles":{"lazy_load":"https:\/\/meustc.com\/wp-content\/themes\/blocksy\/static\/bundle\/non-critical-styles.min.css?ver=2.0.3","flexy_styles":"https:\/\/meustc.com\/wp-content\/themes\/blocksy\/static\/bundle\/flexy.min.css?ver=2.0.3","search_lazy":"https:\/\/meustc.com\/wp-content\/themes\/blocksy\/static\/bundle\/non-critical-search-styles.min.css?ver=2.0.3","back_to_top":"https:\/\/meustc.com\/wp-content\/themes\/blocksy\/static\/bundle\/back-to-top.min.css?ver=2.0.3"},"dynamic_styles_selectors":[{"selector":"#account-modal","url":"https:\/\/meustc.com\/wp-content\/plugins\/blocksy-companion\/static\/bundle\/header-account-modal-lazy.min.css?ver=2.0.3"},{"selector":".ct-header-account","url":"https:\/\/meustc.com\/wp-content\/plugins\/blocksy-companion\/static\/bundle\/header-account-dropdown-lazy.min.css?ver=2.0.3"}]};
</script>
<script src="https://meustc.com/wp-content/themes/blocksy/static/bundle/main.js?ver=2.0.3" id="ct-scripts-js"></script>

</body>
</html>


<!-- Page cached by LiteSpeed Cache 6.1 on 2024-02-18 20:30:10 -->